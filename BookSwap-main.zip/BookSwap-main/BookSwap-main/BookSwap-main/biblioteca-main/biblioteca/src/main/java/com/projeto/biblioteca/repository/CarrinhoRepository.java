package com.projeto.biblioteca.repository;

import com.projeto.biblioteca.model.Carrinho;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarrinhoRepository extends JpaRepository<Carrinho, Long> {
    // Pode adicionar métodos específicos de consulta, se necessário
}

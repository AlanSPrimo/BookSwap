package com.projeto.biblioteca.repository;

import com.projeto.biblioteca.model.Transacao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransacaoRepository extends JpaRepository<Transacao, Long> {
    // Pode adicionar métodos específicos de consulta, se necessário
}

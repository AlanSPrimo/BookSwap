package com.projeto.biblioteca.model;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Livro {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String titulo;
    private String autor;
    private String isbn;
    private boolean disponivel = true;
    private int quantidade;
    private int copiasDisponiveis;
    private double preco;  // Campo adicionado para preço

    // Construtor padrão
    public Livro() {}

    // Construtor com preço
    public Livro(String titulo, String autor, String isbn, Integer quantidade, double preco) {
        this.titulo = titulo;
        this.autor = autor;
        this.isbn = isbn;
        this.quantidade = quantidade;
        this.preco = preco;  // Inicialização do preço
    }

    // Getters e setters
    public Long getId() {return id; }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public Integer getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(Integer quantidade) {
        this.quantidade = quantidade;
    }

    // Metodo getPreco
    public double getPreco() {
        return preco;
    }

    // Metodo setPreco
    public void setPreco(double preco) {
        this.preco = preco;
    }



    public int getCopiasDisponiveis() {
        return copiasDisponiveis;
    }

    public void setCopiasDisponiveis(int copiasDisponiveis) {
        this.copiasDisponiveis = copiasDisponiveis;
    }
}

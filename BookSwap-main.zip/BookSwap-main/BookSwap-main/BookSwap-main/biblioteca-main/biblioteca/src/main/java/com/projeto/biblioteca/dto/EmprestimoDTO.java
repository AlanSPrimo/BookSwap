package com.projeto.biblioteca.dto;

import lombok.Data;

@Data
public class EmprestimoDTO {
    private Long livroId;
    private Long usuarioId;
}
package com.projeto.biblioteca.dto;

import lombok.Data;
import com.projeto.biblioteca.model.Role;

// @Data é uma anotação do Lombok que gera automaticamente os métodos boilerplate
// para uma classe Java, como getters para todos os campos, setters para campos não-finais,
// equals, hashCode e toString. Isso reduz a quantidade de código manual necessário.
@Data
public class UsuarioDTO {
    private String nome;
    private String email;
    private String senha;

    // Getters e Setters
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }

    // Declara um campo privado chamado 'role' do tipo Role.
    // 'Role' é um enum que define os diferentes papéis dos usuários na aplicação
    // (por exemplo, ADMIN ou CLIENTE). Este campo indica o nível de acesso ou as
    // permissões do usuário.
    private Role role; // admin ou cliente
}